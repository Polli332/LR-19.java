package com.cookbook;


public interface ButtonRemoveClickListener {
    void onClick(int position);
}
